AGRITECH SERVICES — SITE VITRINE GRATUIT

Fichier : index.html

Publication gratuite avec GitHub Pages :
1. Créez un compte sur https://github.com/
2. Créez un dépôt public nommé agritech-services
3. Ajoutez index.html à la racine du dépôt
4. Ouvrez Settings > Pages
5. Choisissez Deploy from a branch, puis main et /(root)
6. Enregistrez : GitHub affiche l'adresse publique du site.

E-mail affiché : contactagritech.services@gmail.com

Avant publication, vérifiez les prestations réellement proposées et ajoutez
les mentions légales nécessaires (identité de l'entreprise, coordonnées,
hébergeur, etc.). Ne revendiquez aucune habilitation ou certification non détenue.
